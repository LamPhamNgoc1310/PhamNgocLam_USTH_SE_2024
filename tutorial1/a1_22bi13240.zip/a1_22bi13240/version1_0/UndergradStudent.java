package version1_0;

import utils.*;

public class UndergradStudent extends Student {

    private static final double MIN_ID = 10^5;
    private static final double MAX_ID = 10^8;
    @DomainConstraint(mutable = false, optional = false, min = MIN_ID, max = MAX_ID)
    int id;
	public UndergradStudent(int id, String name, String address) {
		super(id, name, address);
		
		// TODO Auto-generated constructor stub
	}

}
