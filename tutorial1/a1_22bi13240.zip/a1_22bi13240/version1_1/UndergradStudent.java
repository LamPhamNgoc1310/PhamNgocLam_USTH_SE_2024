package version1_1;

import utils.*;
/**
 * Header specification
 * @overview
 *  This is the Student class.
 * @attributes
 *  id      	Integer int
 *  name    	String
 *  phoneNumber	String
 *  address 	String
 * @object
 *  A typical Student is (id, name, phoneNumber, address)
 * @abstract_properties
 *  mutable(id) = false /\ optional(id) = false /\ min(id) = MIN_ID /\ max(id) = MAX_ID/\
 *  mutable(name) = true /\ optional(id) = false /\ length(name) = LEN_NAME /\
 *  mutable(phoneNumber) = true /\ optional(phoneNumber) = false /\ length(phoneNumber)=LEN_PHONE/\
 *  optional(address) = false /\ length(address) = LEN_ADDRESS /\
 *  
 * @author Lam Ngoc Pham
 * 
 * @version 1.1
 */
public class UndergradStudent extends Student {

    private static final double MIN_ID = 10^5;
    private static final double MAX_ID = 10^8;
    @DomainConstraint(mutable = false, optional = false, min = MIN_ID, max = MAX_ID)
    int id;
	public UndergradStudent(@AttrRef("id") int id, 
    @AttrRef("name") String name, 
    @AttrRef("phoneNumber") String phoneNumber, 
    @AttrRef("address") String address) {
        super(id, name, phoneNumber, address);
    }
    @Override
	public String toString() {

		//version: String format
		return String.format("Student(%d)", this.id);
	}
	
	@Override
	public boolean equals(Object o) {
		// todo
		return false; //dummy
	}

    
}
