package version1_0;


import utils.*;

/**
 * Header specification
 * @overview
 *  This is the Student class.
 * @attributes
 *  id      Integer int
 *  name    String
 *  dob     Date
 *  address String
 * @object
 *  A typical Student is (id, name)
 * @abstract_properties
 *  mutable(id) = false /\ optional(id) = false /\ min(id) = 1 /\ max(id) = 10^9 /\
 *  mutable(name) = true /\ optional(id) = false /\ length(name) = 50 /\
 *  optional(address) = true /\
 *  
 * @author Lam Ngoc Pham
 * 
 * @version 1.0
 */
public class Student {
	
	private static final int MIN_ID = 1;
	private static final int LEN_NAME = 50;
	private static final int LEN_PHONE = 10;
	private static final int LEN_ADDRESS = 100;
	private static final double MAX_ID = 10^9;
    
    /** OBJECT REPRESENTATION
     * - field declaration ( <= @attributes)
     * - domain constraints ( <= @abstract_properties)
     */
	@DomainConstraint(mutable = false, optional = false, min = MIN_ID, max = MAX_ID)
	private int id;
	@DomainConstraint(mutable = true, optional = false, length = LEN_NAME)
	private String name;
	@DomainConstraint(mutable = true, optional = false, length = LEN_PHONE)
	private String phoneNumber;
	@DomainConstraint(mutable = true, optional = false, length = LEN_ADDRESS)
	private String address;

	/** OPERATION SPECIFICATION 
	 *  types: constructor, mutator, observer, default, helper
	 *  
	 *  */
	
	//constructor
	/**
	 * @requires	(pre-conditions)
	 *  (empty) 
	 * @effects		(post-conditions)
	 *  if id, name are valid
	 *  	initialize this as Student(name=name, id=id)
	 *  else
	 *  	throws new NotPossibleException 
	 * @modifies	(side-effects)
	 *  (empty)
	 */
	public Student(
			@AttrRef("id")
			int id,
			@AttrRef("name")
			String name,
			String address) {
		// todo
	}
	
	// mutator
	/**
	 * This is the mutator for name
	 * @effects
	 * 
	 * @version
	 * 
	 * 
	 * */
	@DOpt(type=OptType.Mutator) @AttrRef("name")
	public boolean setName() {
		// todo
		return false; //dummy
		
	}
	// observer
	/**
	 * this is the observer for id
	 * @effects
	 *  return this.id
	 * @version
	 * 
	 * */
	@DOpt(type=OptType.Observer) @AttrRef("id")
	public int getId() {
		// todo
		return -1; //dummy
	}
	/**
	 * this is the observer for id
	 * @effects
	 *  return this.name
	 * @version
	 * 
	 * */
	@DOpt(type=OptType.Observer) @AttrRef("name")
	public String getName() {
		// todo
		return null; //dummy
	}
	// default
	@Override
	public String toString() {
			// todo
			return null; //dummy
	}
	
	@Override
	public boolean equals(Object o) {
		// todo
		return false; //dummy
	}
	
	// helper
	
	// validation methods
	/**
	 * validate id against domain constraint
	 * @effects
	 *  if name is valid
	 *  	return true
	 *  else
	 *  	return false
	 * 
	 */
	private boolean validateId(int id) {
		// todo
		return false; //dummy
	}
	
	/**
	 * validate name against domain constraint
	 * @effects
	 *  if name is valid
	 *  	return true
	 *  else
	 *  	return false
	 * 
	 */
	private boolean validateName(String name) {
		// todo
		return false; //dummy
	}
	
}




