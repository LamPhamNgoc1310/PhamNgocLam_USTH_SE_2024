package version1_0;

import utils.DomainConstraint;

public class PostgradStudent extends Student {

    private static final double MIN_ID = 10^8+1;
	private static final double MAX_ID = 10^9;

    @DomainConstraint(mutable=true, optional=false, min=0.0, max=4.0)
    double gpa;

    @DomainConstraint(mutable=true, optional=false, min=MIN_ID, max=MAX_ID)
    int id;
	public PostgradStudent(int id, String name, String address) {
		super(id, name, address);
	}

}
