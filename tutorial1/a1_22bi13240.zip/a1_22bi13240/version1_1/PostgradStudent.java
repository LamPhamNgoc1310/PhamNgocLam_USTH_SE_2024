package version1_1;

import utils.AttrRef;
import utils.DOpt;
import utils.DomainConstraint;
import utils.NotPossibleException;
import utils.OptType;

/**
 * Header specification
 * 
 * @overview
 *           This is the Student class.
 * @attributes
 *             id Integer int
 *             name String
 *             phoneNumber String
 *             address String
 * @object
 *         A typical Student is (id, name, phoneNumber, address)
 * @abstract_properties
 *                      mutable(id) = false /\ optional(id) = false /\ min(id) =
 *                      MIN_ID /\ max(id) = MAX_ID/\
 *                      mutable(name) = true /\ optional(id) = false /\
 *                      length(name) = LEN_NAME /\
 *                      mutable(phoneNumber) = true /\ optional(phoneNumber) =
 *                      false /\ length(phoneNumber)=LEN_PHONE/\
 *                      optional(address) = false /\ length(address) =
 *                      LEN_ADDRESS /\
 * 
 * @author Lam Ngoc Pham
 * 
 * @version 1.1
 */
public class PostgradStudent extends Student {

    private static final double MIN_ID = 10 ^ 8 + 1;
    private static final double MAX_ID = 10 ^ 9;
    @DomainConstraint(mutable = true, optional = false, min = 0.0, max = 4.0)
    double gpa;
    @DomainConstraint(mutable = true, optional = false, min = MIN_ID, max = MAX_ID)
    int id;

    public PostgradStudent(@AttrRef("id") int id, 
    @AttrRef("name") String name, 
    @AttrRef("phoneNumber") String phoneNumber, 
    @AttrRef("address") String address,
    @AttrRef("gpa") double gpa) {
        super(id, name, phoneNumber, address);
        if (validateGpa(gpa)) {
            this.gpa = gpa;
        } else {
            throw new NotPossibleException("Invalid  GPA Input" + gpa);
        }
    }
    @Override
    public String toString() {
        // version: String format
        return String.format("Student(%d)", id);

    }

    @Override
    public boolean equals(Object o) {
        // todo
        return false;
    }

    /**
     * This is the mutator for gpa
     * 
     * @effects
     * 
     * @version
     * 
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("gpa")
    public boolean setAddress(double gpa) {
        if (validateGpa(gpa)) {
            this.gpa = gpa;
            return true;
        } else {
            return false;
        }
    }
    // observer
    /**
     * this is the observer for gpa
     * 
     * @effects
     *          return this.gpa
     * @version
     * 
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("gpa")
    public double getGpa() {
        return gpa;
    }
    // validation methods
    /**
     * validate id against domain constraint
     * 
     * @effects
     *          if name is valid
     *          return true
     *          else
     *          return false
     * 
     */
    private boolean validateGpa(double gpa) {

        return gpa >= MIN_ID && gpa < MAX_ID; // dummy
    }
}
