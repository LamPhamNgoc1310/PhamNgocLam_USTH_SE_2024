package a2_22bi13240.studentman;

public interface Document {
	public String toHtmlDoc();
}
