package version1_1;

import utils.*;

/**
 * Header specification
 * 
 * @overview
 *           This is the Student class.
 * @attributes
 *             id Integer int
 *             name String
 *             phoneNumber String
 *             address String
 * @object
 *         A typical Student is (id, name, phoneNumber, address)
 * @abstract_properties
 *                      mutable(id) = false /\ optional(id) = false /\ min(id) =
 *                      MIN_ID /\ max(id) = MAX_ID/\
 *                      mutable(name) = true /\ optional(id) = false /\
 *                      length(name) = LEN_NAME /\
 *                      mutable(phoneNumber) = true /\ optional(phoneNumber) =
 *                      false /\ length(phoneNumber)=LEN_PHONE/\
 *                      optional(address) = false /\ length(address) =
 *                      LEN_ADDRESS /\
 * 
 * @author Lam Ngoc Pham
 * 
 * @version 1.1
 */
public class Student {

    private static final int MIN_ID = 1;
    private static final int MAX_ID = 10 ^ 9;
    private static final int LEN_NAME = 50;
    private static final int LEN_PHONE = 10;
    private static final int LEN_ADDRESS = 100;
    /**
     * OBJECT REPRESENTATION
     * - field declaration ( <= @attributes)
     * - domain constraints ( <= @abstract_properties)
     */
    @DomainConstraint(mutable = false, optional = false, min = MIN_ID, max = MAX_ID)
    private int id;
    @DomainConstraint(mutable = true, optional = false, length = LEN_NAME)
    private String name;
    @DomainConstraint(mutable = true, optional = false, length = LEN_PHONE)
    private String phoneNumber;
    @DomainConstraint(mutable = true, optional = false, length = LEN_ADDRESS)
    private String address;

    /**
     * OPERATION SPECIFICATION
     * types: constructor, mutator, observer, default, helper
     * 
     */

    // constructor
    /**
     * @requires (pre-conditions)
     *           (empty)
     * @effects (post-conditions)
     *          if id, name are valid
     *          initialize this as Student(name=name, id=id)
     *          else
     *          throws new NotPossibleException
     * @modifies (side-effects)
     *           (empty)
     */

    // constructor
    public Student(
            @AttrRef("id") int id,
            @AttrRef("name") String name,
            @AttrRef("phoneNumber") String phoneNumber,
            @AttrRef("address") String address) {
        if (validateId(id)) {
            this.id = id;
        } else {
            throw new NotPossibleException("Invalid  Id Input" + id);
        }

        if (validateName(name)) {
            this.name = name;
        } else {
            throw new NotPossibleException("Invalid Name Input" + name);
        }
    }

    // mutator
    /**
     * This is the mutator for name
     * 
     * @effects
     * 
     * @version
     * 
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("name")
    public boolean setName(String name) {
        if (validateName(name)) {
            this.name = name;
            return true;
        } else {
            return false; // dummy
        }

    }

    /**
     * This is the mutator for id
     * 
     * @effects
     * 
     * @version
     * 
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("id")
    public boolean setId(int id) {
        if (validateId(id)) {
            this.id = id;
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is the mutator for phoneNumber
     * 
     * @effects
     * 
     * @version
     * 
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("phoneNumber")
    public boolean setPhone(String phoneNumber) {
        if (validatePhone(phoneNumber)) {
            this.phoneNumber = phoneNumber;
            return true;
        } else {
            return false;
        }
    }

    /**
     * This is the mutator for address
     * 
     * @effects
     * 
     * @version
     * 
     */
    @DOpt(type = OptType.Mutator)
    @AttrRef("address")
    public boolean setAddress(String address) {
        if (validateAddress(address)) {
            this.address = address;
            return true;
        } else {
            return false;
        }
    }

    // observer
    /**
     * this is the observer for id
     * 
     * @effects
     *          return this.id
     * @version
     * 
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("id")
    public int getId() {
        return this.id; // dummy
    }

    /**
     * this is the observer for name
     * 
     * @effects
     *          return this.name
     * @version
     * 
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("name")
    public String getName() {
        return this.name; // dummy
    }

    /**
     * this is the observer for phoneNumber
     * 
     * @effects
     *          return this.name
     * @version
     * 
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("phoneNumber")
    public String getPhone() {
        return this.phoneNumber; // dummy
    }

    /**
     * this is the observer for address
     * 
     * @effects
     *          return this.address
     * @version
     * 
     */
    @DOpt(type = OptType.Observer)
    @AttrRef("address")
    public String getAddress() {
        return this.address;
    }

    // default
    @Override
    public String toString() {
        // version: String format
        return String.format("Student(%d,%s)", id, name);

    }

    @Override
    public boolean equals(Object o) {
        // todo
        return false; // dummy
    }

    // helper

    // validation methods
    /**
     * validate id against domain constraint
     * 
     * @effects
     *          if name is valid
     *          return true
     *          else
     *          return false
     * 
     */
    private boolean validateId(int id) {

        return id >= MIN_ID && id < MAX_ID; // dummy
    }

    /**
     * validate name against domain constraint
     * 
     * @effects
     *          if name is valid
     *          return true
     *          else
     *          return false
     * 
     */
    private boolean validateName(String name) {
        if (name == null) {
            return false;
        }
        return name.length() <= LEN_NAME; // dummy
    }

    /**
     * validate phoneNumber against domain constraint
     * 
     * @effects
     *          if phoneNumber is valid
     *          return true
     *          else
     *          return false
     * 
     */
    private boolean validatePhone(String phoneNumber) {
        if (phoneNumber == null) {
            return false;
        }
        return phoneNumber.length() <= LEN_PHONE; // dummy
    }

    /**
     * validate phoneNumber against domain constraint
     * 
     * @effects
     *          if phoneNumber is valid
     *          return true
     *          else
     *          return false
     * 
     */
    private boolean validateAddress(String address) {
        if (address == null) {
            return false;
        }
        return address.length() <= LEN_ADDRESS; // dummy
    }

}
